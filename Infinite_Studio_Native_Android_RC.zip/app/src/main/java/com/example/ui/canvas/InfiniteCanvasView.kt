package com.example.ui.canvas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.viewinterop.AndroidView
import com.example.document.ConstraintKind
import com.example.document.Vec2
import com.example.input.PointerIntent
import com.example.input.StrokeSample
import com.example.input.StylusDiagnostics
import com.example.input.StylusInputRouter
import com.example.model.PaperStyle
import com.example.model.ShapeGuide
import com.example.model.StudioTool
import com.example.model.StudioUiState
import com.example.model.SymmetryMode
import com.example.render.SparseTileRenderer
import com.example.tools.TileBrushEngine
import kotlin.math.max
import kotlin.math.min

/**
 * Native Android View host wired to Compose via AndroidView so raw MotionEvent streams
 * (S-Pen stylus vs touch vs eraser, historical batched samples, tilt, pressure, hover,
 * ACTION_CANCEL, and Android 13+ FLAG_CANCELED) flow directly into StylusInputRouter and
 * SparseTileRenderer at full refresh cadence without Compose recomposition overhead.
 */
@Composable
fun InfiniteCanvasView(
    state: StudioUiState,
    tileRenderer: SparseTileRenderer,
    onViewportSizeChanged: (IntSize) -> Unit,
    onUpdateViewport: (scale: Float, offsetX: Float, offsetY: Float) -> Unit,
    onBeginPointer: (worldPos: PointF, pressure: Float) -> Pair<PointF?, PointF?>,
    onMovePointer: (worldPos: PointF, pressure: Float) -> Pair<PointF?, PointF?>,
    onEndPointer: () -> Unit,
    onCancelStroke: () -> Unit,
    onTwoFingerTapUndo: () -> Unit,
    onThreeFingerTapRedo: () -> Unit,
    onStylusDiagnostics: (StylusDiagnostics) -> Unit,
    modifier: Modifier = Modifier
) {
    val latestState by rememberUpdatedState(state)
    val latestOnUpdateViewport by rememberUpdatedState(onUpdateViewport)
    val latestOnBeginPointer by rememberUpdatedState(onBeginPointer)
    val latestOnMovePointer by rememberUpdatedState(onMovePointer)
    val latestOnEndPointer by rememberUpdatedState(onEndPointer)
    val latestOnCancelStroke by rememberUpdatedState(onCancelStroke)
    val latestOnUndo by rememberUpdatedState(onTwoFingerTapUndo)
    val latestOnRedo by rememberUpdatedState(onThreeFingerTapRedo)
    val latestOnDiag by rememberUpdatedState(onStylusDiagnostics)

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("studio_canvas_viewport")
            .onSizeChanged { onViewportSizeChanged(it) }
    ) {
        AndroidView(
            factory = { ctx ->
                StudioNativeCanvasView(
                    context = ctx,
                    tileRenderer = tileRenderer,
                    getState = { latestState },
                    onUpdateViewport = { s, ox, oy -> latestOnUpdateViewport(s, ox, oy) },
                    onBeginPointer = { wp, p -> latestOnBeginPointer(wp, p) },
                    onMovePointer = { wp, p -> latestOnMovePointer(wp, p) },
                    onEndPointer = { latestOnEndPointer() },
                    onCancelStroke = { latestOnCancelStroke() },
                    onTwoFingerTapUndo = { latestOnUndo() },
                    onThreeFingerTapRedo = { latestOnRedo() },
                    onDiagnostics = { latestOnDiag(it) }
                )
            },
            update = { view ->
                view.syncSelectionAnimation(state.selection.active)
                view.invalidate()
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

private class StudioNativeCanvasView(
    context: Context,
    private val tileRenderer: SparseTileRenderer,
    private val getState: () -> StudioUiState,
    private val onUpdateViewport: (Float, Float, Float) -> Unit,
    private val onBeginPointer: (PointF, Float) -> Pair<PointF?, PointF?>,
    private val onMovePointer: (PointF, Float) -> Pair<PointF?, PointF?>,
    private val onEndPointer: () -> Unit,
    private val onCancelStroke: () -> Unit,
    private val onTwoFingerTapUndo: () -> Unit,
    private val onThreeFingerTapRedo: () -> Unit,
    private val onDiagnostics: (StylusDiagnostics) -> Unit
) : View(context) {

    private var dashPhase: Float = 0f
    private var selectionAnimating: Boolean = false
    private val marqueeTicker = object : Runnable {
        override fun run() {
            if (selectionAnimating) {
                dashPhase = (dashPhase - 1.5f) % 32f
                invalidate()
                postDelayed(this, 32L)
            }
        }
    }

    private val provisionalSamples = mutableListOf<Pair<Vec2, Float>>()
    private var shapePreviewStart: PointF? = null
    private var shapePreviewEnd: PointF? = null
    private var hoverWorldPos: PointF? = null
    private var hoverIntent: PointerIntent = PointerIntent.TOUCH

    // Cached Paints, Shader & Path to eliminate per-frame allocations inside onDraw()
    private val checkerPaint: Paint by lazy {
        val cell = 24
        val tile = Bitmap.createBitmap(cell * 2, cell * 2, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        c.drawColor(Color.rgb(18, 18, 20))
        val light = Paint().apply { color = Color.rgb(24, 24, 27) }
        c.drawRect(0f, 0f, cell.toFloat(), cell.toFloat(), light)
        c.drawRect(cell.toFloat(), cell.toFloat(), (cell * 2).toFloat(), (cell * 2).toFloat(), light)
        Paint().apply {
            shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        }
    }

    private val originPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(56, 161, 161, 170)
        style = Paint.Style.STROKE
    }
    private val symPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(145, 56, 189, 248)
        style = Paint.Style.STROKE
    }
    private val stagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(80, 129, 140, 248)
        style = Paint.Style.STROKE
    }
    private val rulerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 245, 158, 11)
        style = Paint.Style.STROKE
    }
    private val constraintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val guidancePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val shapePreviewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val marqueeFillPaint = Paint().apply {
        color = Color.argb(22, 56, 189, 248)
        style = Paint.Style.FILL
    }
    private val marqueeStrokeWhite = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
    }
    private val marqueeStrokeBlue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(2, 132, 199)
        style = Paint.Style.STROKE
    }
    private val hoverRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val scratchPath = Path()

    private var cachedDashScale: Float = -1f
    private var cachedSymDash: DashPathEffect? = null
    private var cachedRulerDash: DashPathEffect? = null
    private var cachedConstraintDash: DashPathEffect? = null
    private var cachedGuidanceDash: DashPathEffect? = null

    fun syncSelectionAnimation(active: Boolean) {
        if (active && !selectionAnimating) {
            selectionAnimating = true
            removeCallbacks(marqueeTicker)
            postDelayed(marqueeTicker, 32L)
        } else if (!active && selectionAnimating) {
            selectionAnimating = false
            removeCallbacks(marqueeTicker)
        }
    }

    override fun onDetachedFromWindow() {
        selectionAnimating = false
        removeCallbacks(marqueeTicker)
        super.onDetachedFromWindow()
    }

    private fun ensureScaledDashEffects(viewScale: Float) {
        if (cachedDashScale == viewScale) return
        cachedDashScale = viewScale
        cachedSymDash = DashPathEffect(floatArrayOf(8f / viewScale, 6f / viewScale), 0f)
        cachedRulerDash = DashPathEffect(floatArrayOf(6f / viewScale, 6f / viewScale), 0f)
        cachedConstraintDash = DashPathEffect(floatArrayOf(10f / viewScale, 6f / viewScale), 0f)
        cachedGuidanceDash = DashPathEffect(floatArrayOf(12f / viewScale, 8f / viewScale), 0f)
    }

    private val router = StylusInputRouter(
        onBeginStroke = { sample ->
            val wp = PointF(sample.worldX, sample.worldY)
            provisionalSamples.clear()
            val st = getState()
            val isBrushStroke = st.shapeGuide == ShapeGuide.FREEHAND && st.activeTool !in listOf(
                StudioTool.LASSO, StudioTool.RECT_SELECT, StudioTool.TRANSFORM,
                StudioTool.FILL, StudioTool.EYEDROPPER, StudioTool.ERASER
            )
            if (isBrushStroke) {
                provisionalSamples.add(Vec2(sample.worldX, sample.worldY) to sample.pressure)
            }
            val (s, e) = onBeginPointer(wp, sample.pressure)
            shapePreviewStart = s
            shapePreviewEnd = e
            invalidate()
        },
        onMoveStroke = { samples: List<StrokeSample> ->
            val st = getState()
            val isBrushStroke = st.shapeGuide == ShapeGuide.FREEHAND && st.activeTool !in listOf(
                StudioTool.LASSO, StudioTool.RECT_SELECT, StudioTool.TRANSFORM,
                StudioTool.FILL, StudioTool.EYEDROPPER, StudioTool.ERASER
            )
            for (s in samples) {
                if (isBrushStroke) {
                    provisionalSamples.add(Vec2(s.worldX, s.worldY) to s.pressure)
                }
                val (ps, pe) = onMovePointer(PointF(s.worldX, s.worldY), s.pressure)
                if (ps != null || pe != null) {
                    shapePreviewStart = ps
                    shapePreviewEnd = pe
                }
            }
            invalidate()
        },
        onEndStroke = {
            provisionalSamples.clear()
            shapePreviewStart = null
            shapePreviewEnd = null
            onEndPointer()
            invalidate()
        },
        onCancelStroke = {
            provisionalSamples.clear()
            shapePreviewStart = null
            shapePreviewEnd = null
            onCancelStroke()
            invalidate()
        },
        onHoverMove = { wp, intent ->
            hoverWorldPos = wp
            hoverIntent = intent
            invalidate()
        },
        onPanZoom = { scaleDelta, dx, dy ->
            val st = getState()
            val nextScale = (st.viewScale * scaleDelta).coerceIn(0.15f, 4.0f)
            onUpdateViewport(nextScale, st.viewOffsetX + dx, st.viewOffsetY + dy)
        },
        onTwoFingerTapUndo = { onTwoFingerTapUndo() },
        onThreeFingerTapRedo = { onThreeFingerTapRedo() }
    )

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val st = getState()
        val handled = router.handleMotionEvent(
            event = event,
            viewportWidth = max(1, width).toFloat(),
            viewportHeight = max(1, height).toFloat(),
            viewScale = st.viewScale,
            viewOffsetX = st.viewOffsetX,
            viewOffsetY = st.viewOffsetY,
            sPenGuardEnabled = st.sPenOnly
        )
        onDiagnostics(router.diagnostics)
        return handled
    }

    override fun onHoverEvent(event: MotionEvent): Boolean {
        val st = getState()
        val handled = router.handleMotionEvent(
            event = event,
            viewportWidth = max(1, width).toFloat(),
            viewportHeight = max(1, height).toFloat(),
            viewScale = st.viewScale,
            viewOffsetX = st.viewOffsetX,
            viewOffsetY = st.viewOffsetY,
            sPenGuardEnabled = st.sPenOnly
        )
        onDiagnostics(router.diagnostics)
        return handled
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val state = getState()
        val vw = width.toFloat()
        val vh = height.toFloat()
        val scale = max(0.05f, state.viewScale)
        ensureScaledDashEffects(scale)

        // 1. Paper or cached BitmapShader Checkerboard (single draw call)
        if (state.paperStyle == PaperStyle.TRANSPARENT) {
            canvas.drawRect(0f, 0f, vw, vh, checkerPaint)
        } else {
            canvas.drawColor(state.paperStyle.colorInt)
        }

        canvas.save()
        canvas.translate(vw / 2f + state.viewOffsetX, vh / 2f + state.viewOffsetY)
        canvas.scale(scale, scale)

        // 2. Sparse 256x256 tile composite + vectors + onion skin
        tileRenderer.renderDocumentViewport(
            nativeCanvas = canvas,
            doc = state.document,
            viewportWidth = vw,
            viewportHeight = vh,
            viewScale = scale,
            viewOffsetX = state.viewOffsetX,
            viewOffsetY = state.viewOffsetY
        )

        // 3. Zero-lag provisional stroke overlay before commit
        if (provisionalSamples.isNotEmpty() && state.activeTool != StudioTool.AI_GUIDANCE) {
            val params = TileBrushEngine.StrokeRenderParams(
                tool = state.activeTool,
                colorInt = state.brushColorInt,
                preset = state.activeBrushPreset,
                symmetryMode = state.symmetryMode,
                activeMask = state.activeSelectionMask
            )
            TileBrushEngine.renderStrokeOnCanvas(
                canvas = canvas,
                canvasBounds = state.document.bounds,
                worldPoints = provisionalSamples,
                params = params,
                alphaLock = false
            )
        }

        // 4. Origin Crosshair
        originPaint.strokeWidth = 1.5f / scale
        canvas.drawLine(-16f, 0f, 16f, 0f, originPaint)
        canvas.drawLine(0f, -16f, 0f, 16f, originPaint)

        // 5. Symmetry Guides
        val b = state.document.bounds
        if (state.symmetryMode != SymmetryMode.NONE) {
            symPaint.strokeWidth = 2f / scale
            symPaint.pathEffect = cachedSymDash
            if (state.symmetryMode in listOf(SymmetryMode.VERTICAL, SymmetryMode.QUADRANT, SymmetryMode.KALEIDOSCOPE)) {
                canvas.drawLine(0f, b.minY, 0f, b.maxY, symPaint)
            }
            if (state.symmetryMode in listOf(SymmetryMode.HORIZONTAL, SymmetryMode.QUADRANT, SymmetryMode.KALEIDOSCOPE)) {
                canvas.drawLine(b.minX, 0f, b.maxX, 0f, symPaint)
            }
            if (state.symmetryMode == SymmetryMode.KALEIDOSCOPE) {
                canvas.drawLine(-3000f, -3000f, 3000f, 3000f, symPaint)
                canvas.drawLine(3000f, -3000f, -3000f, 3000f, symPaint)
            }
        }

        // 6. Spatial Stage 2.5D Perspective Vanishing Lines
        if (state.document.spatialStage.enabled) {
            val vp = state.document.spatialStage.vanishingPoint
            stagePaint.strokeWidth = 1.5f / scale
            val bMaxY = b.maxY
            canvas.drawLine(vp.x, vp.y, -1200f, bMaxY, stagePaint)
            canvas.drawLine(vp.x, vp.y, -600f, bMaxY, stagePaint)
            canvas.drawLine(vp.x, vp.y, 0f, bMaxY, stagePaint)
            canvas.drawLine(vp.x, vp.y, 600f, bMaxY, stagePaint)
            canvas.drawLine(vp.x, vp.y, 1200f, bMaxY, stagePaint)
            canvas.drawCircle(vp.x, vp.y, 10f / scale, stagePaint)
        }

        // 7. Character Studio Proportion Ruler (8-head grid)
        val charSheet = state.document.characterSheets.firstOrNull()
        if (charSheet?.showProportionRuler == true) {
            rulerPaint.strokeWidth = 1.2f / scale
            rulerPaint.pathEffect = cachedRulerDash
            for (headIdx in -4..4) {
                val hy = headIdx * 75f
                canvas.drawLine(-420f, hy, 420f, hy, rulerPaint)
            }
        }

        // 8. Constraint Constellation Overlays
        state.document.constraints.forEach { c ->
            if (c.points.size >= 3) {
                scratchPath.reset()
                scratchPath.moveTo(c.points[0].x, c.points[0].y)
                for (i in 1 until c.points.size) scratchPath.lineTo(c.points[i].x, c.points[i].y)
                scratchPath.close()
                constraintPaint.strokeWidth = 2.5f / scale
                constraintPaint.color = when (c.kind) {
                    ConstraintKind.FORBIDDEN_REGION -> Color.argb(200, 239, 68, 68)
                    ConstraintKind.PROTECTED_SILHOUETTE -> Color.argb(200, 16, 185, 129)
                    else -> Color.argb(180, 245, 158, 11)
                }
                constraintPaint.pathEffect = cachedConstraintDash
                canvas.drawPath(scratchPath, constraintPaint)
            }
        }

        // 9. AI Brush Guidance Marks
        state.document.guidanceMarks.forEach { g ->
            if (g.points.size >= 2) {
                scratchPath.reset()
                scratchPath.moveTo(g.points[0].x, g.points[0].y)
                for (i in 1 until g.points.size) scratchPath.lineTo(g.points[i].x, g.points[i].y)
                guidancePaint.strokeWidth = 4f / scale
                guidancePaint.color = try { Color.parseColor(g.colorHex) } catch (_: Exception) { Color.CYAN }
                guidancePaint.alpha = 180
                guidancePaint.pathEffect = cachedGuidanceDash
                canvas.drawPath(scratchPath, guidancePaint)
            }
        }

        // 10. Live Assisted Shape Preview
        val st = shapePreviewStart
        val en = shapePreviewEnd
        if (state.shapeGuide != ShapeGuide.FREEHAND && st != null && en != null) {
            shapePreviewPaint.color = state.brushColorInt
            shapePreviewPaint.alpha = 190
            shapePreviewPaint.strokeWidth = state.brushSize
            when (state.shapeGuide) {
                ShapeGuide.LINE -> canvas.drawLine(st.x, st.y, en.x, en.y, shapePreviewPaint)
                ShapeGuide.RECT -> canvas.drawRect(min(st.x, en.x), min(st.y, en.y), max(st.x, en.x), max(st.y, en.y), shapePreviewPaint)
                ShapeGuide.ELLIPSE -> canvas.drawOval(min(st.x, en.x), min(st.y, en.y), max(st.x, en.x), max(st.y, en.y), shapePreviewPaint)
                ShapeGuide.FREEHAND -> Unit
            }
        }

        // 11. Active AI Selection Marquee
        if (state.selection.active && state.selection.points.size >= 2) {
            scratchPath.reset()
            val pts = state.selection.points
            scratchPath.moveTo(pts[0].x, pts[0].y)
            for (i in 1 until pts.size) scratchPath.lineTo(pts[i].x, pts[i].y)
            scratchPath.close()

            canvas.drawPath(scratchPath, marqueeFillPaint)
            val dashLen = 8f / scale
            val phaseIntervals = floatArrayOf(dashLen, dashLen)
            marqueeStrokeWhite.strokeWidth = 2.5f / scale
            marqueeStrokeWhite.pathEffect = DashPathEffect(phaseIntervals, dashPhase / scale)
            canvas.drawPath(scratchPath, marqueeStrokeWhite)

            marqueeStrokeBlue.strokeWidth = 2.5f / scale
            marqueeStrokeBlue.pathEffect = DashPathEffect(phaseIntervals, (dashPhase + 8f) / scale)
            canvas.drawPath(scratchPath, marqueeStrokeBlue)
        }

        // 12. Stylus Hover Cursor Ring
        val cursor = hoverWorldPos
        if (cursor != null && state.activeTool !in listOf(
                StudioTool.LASSO, StudioTool.RECT_SELECT, StudioTool.TRANSFORM,
                StudioTool.FILL, StudioTool.EYEDROPPER
            )
        ) {
            hoverRingPaint.color = if (hoverIntent == PointerIntent.STYLUS || hoverIntent == PointerIntent.ERASER) {
                Color.argb(210, 56, 189, 248)
            } else {
                Color.argb(175, 161, 161, 170)
            }
            hoverRingPaint.strokeWidth = 1.5f / scale
            canvas.drawCircle(cursor.x, cursor.y, max(2f, state.brushSize / 2f), hoverRingPaint)
        }

        canvas.restore()
    }
}
