package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.minimumInteractiveComponentSize
import com.example.document.ConstraintKind
import com.example.features.FuturesAndConstraintsEngine
import com.example.features.OrchardSceneNode
import com.example.features.VaultBranchOrchardEngine
import com.example.features.VectorAndFoundryEngine
import com.example.model.StudioUiState
import com.example.services.ProviderMode
import com.example.ui.theme.StudioColors

private val WORKSPACE_TABS = listOf(
    "Surgery & Stage",
    "Vector & Foundry",
    "Material & Time",
    "Recipes & Forensics",
    "Vault, Branch & Director",
    "Constraints & Router"
)

/**
 * Clean tabbed tablet Studio Hub surfacing all 20 Creative Systems (F01-F10, P01-P10)
 * on top of the active CanonicalDocument without crowding the primary canvas.
 */
@Composable
fun StudioWorkspaceSheet(
    state: StudioUiState,
    selectedTab: Int,
    onSelectTab: (Int) -> Unit,
    onExtractObject: (String) -> Unit,
    onNudgeObject: (String, Float, Float) -> Unit,
    onRevertObject: (String) -> Unit,
    onAssignDepthPlane: (String) -> Unit,
    onUpdateSpatialCamera: (Float, Float, Float) -> Unit,
    onAddTextBox: (String) -> Unit,
    onAddBalloon: (String) -> Unit,
    onAddBezier: () -> Unit,
    onExportSvg: () -> Unit,
    onExportFoundry: () -> Unit,
    onApplyTemplate: (String) -> Unit,
    onApplyMaterial: (String, Float, Float, Float, Float) -> Unit,
    onAddFrame: () -> Unit,
    onSelectFrame: (Int) -> Unit,
    onCaptureKeyframes: () -> Unit,
    onToggleOnionSkin: () -> Unit,
    onRenderSpriteSheet: () -> Unit,
    onRunRecipe: () -> Unit,
    onTweakRecipeRoughness: (String) -> Unit,
    onToggleBatteryPause: (Boolean) -> Unit,
    onRunForensics: () -> Unit,
    onSaveToVault: (String, String) -> Unit,
    onToggleVaultApproval: (String, Boolean) -> Unit,
    onToggleRuler: () -> Unit,
    onForkBranch: (String) -> Unit,
    onRollbackBranch: (String) -> Unit,
    onAddOrchardNode: (String) -> Unit,
    onNavigateOrchardNode: (OrchardSceneNode) -> Unit = {},
    onExecuteDirector: (String) -> Unit,
    onAddConstraint: (ConstraintKind, String) -> Unit,
    onToggleConstraintLock: (String) -> Unit,
    onRunOutpaint: (FuturesAndConstraintsEngine.OutpaintDirection) -> Unit,
    onSetProviderMode: (ProviderMode) -> Unit,
    onClose: () -> Unit
) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .safeDrawingPadding()
                .padding(14.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 980.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(StudioColors.FuturesDialogBg)
                    .border(1.dp, StudioColors.FuturesDialogBorder, RoundedCornerShape(24.dp))
                    .padding(18.dp)
                    .testTag("studio_workspace_hub"),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("STUDIO WORKSPACE HUB", style = MaterialTheme.typography.labelMedium.copy(color = StudioColors.SkyAccent, letterSpacing = 1.2.sp))
                        Text("20 Creative Engines · rev ${state.document.revision}", style = MaterialTheme.typography.titleLarge.copy(color = StudioColors.TextPrimary))
                    }
                    Icon(Icons.Filled.Close, "Close Workspace Hub", tint = StudioColors.TextMuted, modifier = Modifier.size(24.dp).clickable(onClick = onClose).testTag("btn_close_hub"))
                }

                // Tabs
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    WORKSPACE_TABS.forEachIndexed { idx, title ->
                        val active = idx == selectedTab
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) StudioColors.SkySoft else Color(0xFF1A242E))
                                .clickable { onSelectTab(idx) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("hub_tab_$idx")
                        ) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = if (active) StudioColors.SkyDarkText else StudioColors.TextSecondary,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                        }
                    }
                }

                HorizontalDivider(color = StudioColors.FuturesDivider)

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (selectedTab) {
                        0 -> SurgeryAndSpatialTab(state, onExtractObject, onNudgeObject, onRevertObject, onAssignDepthPlane, onUpdateSpatialCamera)
                        1 -> VectorAndFoundryTab(state, onAddTextBox, onAddBalloon, onAddBezier, onExportSvg, onExportFoundry, onApplyTemplate)
                        2 -> MaterialAndTimeTab(state, onApplyMaterial, onAddFrame, onSelectFrame, onCaptureKeyframes, onToggleOnionSkin, onRenderSpriteSheet)
                        3 -> RecipesAndForensicsTab(state, onRunRecipe, onTweakRecipeRoughness, onToggleBatteryPause, onRunForensics)
                        4 -> VaultBranchDirectorTab(state, onSaveToVault, onToggleVaultApproval, onToggleRuler, onForkBranch, onRollbackBranch, onAddOrchardNode, onNavigateOrchardNode, onExecuteDirector)
                        5 -> ConstraintsAndRouterTab(state, onAddConstraint, onToggleConstraintLock, onRunOutpaint, onSetProviderMode)
                    }
                }
            }
        }
    }
}

@Composable
private fun SurgeryAndSpatialTab(
    state: StudioUiState,
    onExtract: (String) -> Unit,
    onNudge: (String, Float, Float) -> Unit,
    onRevert: (String) -> Unit,
    onAssignPlane: (String) -> Unit,
    onUpdateCamera: (Float, Float, Float) -> Unit
) {
    var objName by remember { mutableStateOf("Hero Subject") }
    var yaw by remember { mutableFloatStateOf(state.document.spatialStage.cameraYawDeg) }
    var zoom by remember { mutableFloatStateOf(state.document.spatialStage.cameraZoom) }

    Text("F01 Object Surgery (Non-Destructive Extraction + Speculative Repair)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = objName, onValueChange = { objName = it }, label = { Text("Object Name") }, singleLine = true, modifier = Modifier.weight(1f))
        Button(onClick = { onExtract(objName) }, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.SkySoft, contentColor = StudioColors.SkyDarkText), modifier = Modifier.testTag("btn_extract_object")) {
            Text("Extract Selection")
        }
    }
    state.document.semanticObjects.forEach { obj ->
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF151F28)).padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("${obj.name} (${obj.repairLabel})", style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                Text("Bounds: (${obj.boundsX.toInt()}, ${obj.boundsY.toInt()}) ${obj.boundsW.toInt()}x${obj.boundsH.toInt()}", style = MaterialTheme.typography.bodySmall.copy(color = StudioColors.TextMuted))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(onClick = { onNudge(obj.id, 30f, -20f) }) { Text("Nudge +30,-20") }
                OutlinedButton(onClick = { onRevert(obj.id) }) { Text("Revert") }
            }
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("F02 Spatial Stage (2.5D Depth Planes & Camera)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        state.document.spatialStage.depthPlanes.forEach { plane ->
            OutlinedButton(onClick = { onAssignPlane(plane.id) }) {
                Text("Assign Active -> ${plane.name} (${plane.parallaxFactor}x)")
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Yaw ${yaw.toInt()}°", color = StudioColors.TextSecondary, modifier = Modifier.weight(0.25f))
        Slider(value = yaw, onValueChange = { yaw = it }, valueRange = -25f..25f, modifier = Modifier.weight(0.75f))
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Zoom ${String.format("%.2f", zoom)}x", color = StudioColors.TextSecondary, modifier = Modifier.weight(0.25f))
        Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 0.6f..1.6f, modifier = Modifier.weight(0.75f))
    }
    Button(onClick = { onUpdateCamera(yaw, 0f, zoom) }, modifier = Modifier.testTag("btn_render_spatial")) { Text("Render 2.5D Composite Preview") }
    state.spatialPreviewBitmap?.let { bmp ->
        Image(bitmap = bmp.asImageBitmap(), contentDescription = "2.5D Spatial composite", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(10.dp)))
    }
}

@Composable
private fun VectorAndFoundryTab(
    state: StudioUiState,
    onAddText: (String) -> Unit,
    onAddBalloon: (String) -> Unit,
    onAddBezier: () -> Unit,
    onExportSvg: () -> Unit,
    onExportFoundry: () -> Unit,
    onApplyTemplate: (String) -> Unit
) {
    var caption by remember { mutableStateOf("HELLO FUTURES") }
    Text("F09 Vector & Typography Studio (${state.document.vectorObjects.size} objects)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    OutlinedTextField(value = caption, onValueChange = { caption = it }, label = { Text("Vector Text / Speech Balloon Copy") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("input_vector_text"))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onAddText(caption) }, modifier = Modifier.testTag("btn_add_textbox")) { Text("Add Text Box") }
        Button(onClick = { onAddBalloon(caption) }, modifier = Modifier.testTag("btn_add_balloon")) { Text("Add Speech Balloon") }
        OutlinedButton(onClick = onAddBezier) { Text("+ Bezier Arc") }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("F08 Production Foundry & P09 Asset Workshop", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onExportSvg, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.SkySoft, contentColor = StudioColors.SkyDarkText), modifier = Modifier.testTag("btn_export_svg")) { Text("Export Artwork SVG") }
        Button(onClick = onExportFoundry, colors = ButtonDefaults.buttonColors(containerColor = StudioColors.SkySoft, contentColor = StudioColors.SkyDarkText), modifier = Modifier.testTag("btn_export_foundry")) { Text("Export Foundry Bundle (.zip)") }
    }
    Text("Workshop Templates:", style = MaterialTheme.typography.labelMedium.copy(color = StudioColors.TextSecondary))
    VectorAndFoundryEngine.WORKSHOP_TEMPLATES.forEach { tpl ->
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF151F28)).padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(tpl.title, style = MaterialTheme.typography.bodyMedium.copy(color = Color.White))
                Text(tpl.description, style = MaterialTheme.typography.bodySmall.copy(color = StudioColors.TextMuted))
            }
            OutlinedButton(onClick = { onApplyTemplate(tpl.id) }) { Text("Apply") }
        }
    }
}

@Composable
private fun MaterialAndTimeTab(
    state: StudioUiState,
    onApplyMaterial: (String, Float, Float, Float, Float) -> Unit,
    onAddFrame: () -> Unit,
    onSelectFrame: (Int) -> Unit,
    onCaptureKeyframes: () -> Unit,
    onToggleOnionSkin: () -> Unit,
    onRenderSpriteSheet: () -> Unit
) {
    var matName by remember { mutableStateOf("Chrome Rim") }
    var roughness by remember { mutableFloatStateOf(0.28f) }
    var metalness by remember { mutableFloatStateOf(0.75f) }
    var azimuth by remember { mutableFloatStateOf(45f) }

    Text("F06 Material Intelligence (Deterministic Blinn-Phong & Relief)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = matName, onValueChange = { matName = it }, label = { Text("Material") }, singleLine = true, modifier = Modifier.weight(1f))
        Button(onClick = { onApplyMaterial(matName, roughness, metalness, 0.5f, azimuth) }, modifier = Modifier.testTag("btn_bake_material")) { Text("Bake Material Layer") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text("Roughness: ${String.format("%.2f", roughness)}", color = StudioColors.TextSecondary, fontSize = 11.sp)
            Slider(value = roughness, onValueChange = { roughness = it }, valueRange = 0.05f..1f)
        }
        Column(Modifier.weight(1f)) {
            Text("Metalness: ${String.format("%.2f", metalness)}", color = StudioColors.TextSecondary, fontSize = 11.sp)
            Slider(value = metalness, onValueChange = { metalness = it }, valueRange = 0f..1f)
        }
        Column(Modifier.weight(1f)) {
            Text("Light Azimuth: ${azimuth.toInt()}°", color = StudioColors.TextSecondary, fontSize = 11.sp)
            Slider(value = azimuth, onValueChange = { azimuth = it }, valueRange = 0f..360f)
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("F05 Time Canvas (${state.document.timeline.frames.size} frames @ ${state.document.timeline.fps} fps)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Button(onClick = onAddFrame, modifier = Modifier.testTag("btn_add_frame")) { Text("+ Frame") }
        OutlinedButton(onClick = onCaptureKeyframes) { Text("Key Layers") }
        OutlinedButton(onClick = onToggleOnionSkin) { Text(if (state.document.timeline.onionSkinEnabled) "Onion: ON" else "Onion: OFF") }
        Button(onClick = onRenderSpriteSheet, modifier = Modifier.testTag("btn_render_spritesheet")) { Text("Build Sprite Sheet") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        state.document.timeline.frames.forEachIndexed { i, f ->
            val active = i == state.document.timeline.currentFrameIndex
            OutlinedButton(onClick = { onSelectFrame(i) }) {
                Text(if (active) "[${f.label}]" else f.label, color = if (active) StudioColors.SkyAccent else StudioColors.TextSecondary)
            }
        }
    }
    state.spriteSheetPreviewBitmap?.let { bmp ->
        Image(bitmap = bmp.asImageBitmap(), contentDescription = "Sprite sheet preview", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(90.dp).background(Color.Black))
    }
}

@Composable
private fun RecipesAndForensicsTab(
    state: StudioUiState,
    onRunRecipe: () -> Unit,
    onTweakRoughness: (String) -> Unit,
    onToggleBatteryPause: (Boolean) -> Unit,
    onRunForensics: () -> Unit
) {
    Text("F04 Creative Recipes (Acyclic DAG + Selective Invalidation)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onRunRecipe, modifier = Modifier.testTag("btn_run_recipe")) { Text("Execute Recipe DAG") }
        OutlinedButton(onClick = { onTweakRoughness("0.72") }) { Text("Change Material Node (0.72)") }
    }
    Text(state.lastRecipeReportSummary, style = MaterialTheme.typography.bodySmall.copy(color = StudioColors.TextSecondary))

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("F03 Living Preview", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        val paused = state.livingPreview?.isPausedForBattery ?: false
        Text("Low-Power Pause", color = StudioColors.TextSecondary)
        Switch(checked = paused, onCheckedChange = onToggleBatteryPause)
        Text(state.livingPreview?.statusText ?: "", style = MaterialTheme.typography.bodySmall.copy(color = StudioColors.TextMuted))
    }
    state.livingPreview?.bitmap?.let { bmp ->
        Image(bitmap = bmp.asImageBitmap(), contentDescription = "Living preview", contentScale = ContentScale.Fit, modifier = Modifier.height(110.dp).clip(RoundedCornerShape(8.dp)))
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("F07 Visual Forensics (Diff Heatmap & Mask Boundary Proof)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Button(onClick = onRunForensics, modifier = Modifier.testTag("btn_run_forensics")) { Text("Audit Base vs Active Layer") }
    state.forensicsReport?.let { rep ->
        Text("Inside Mask Changed: ${rep.changedPixelsInsideMask} px | Outside Mask Changed: ${rep.changedPixelsOutsideMask} px | Max Delta: ${rep.maxChannelDelta}", color = Color.White, fontSize = 12.sp)
        rep.advisoryChecklist.forEach { Text("• $it", color = StudioColors.TextSecondary, fontSize = 11.sp) }
        Image(bitmap = rep.heatmapBitmap.asImageBitmap(), contentDescription = "Forensics Heatmap", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth().height(120.dp))
    }
}

@Composable
private fun VaultBranchDirectorTab(
    state: StudioUiState,
    onSaveVault: (String, String) -> Unit,
    onToggleApproval: (String, Boolean) -> Unit,
    onToggleRuler: () -> Unit,
    onForkBranch: (String) -> Unit,
    onRollbackBranch: (String) -> Unit,
    onAddOrchardNode: (String) -> Unit,
    onNavigateOrchardNode: (OrchardSceneNode) -> Unit,
    onExecuteDirector: (String) -> Unit
) {
    var vaultTag by remember { mutableStateOf("lantern, sky, key") }
    var branchLabel by remember { mutableStateOf("Alt Lighting") }
    var directorCmd by remember { mutableStateOf("add text CHAPTER ONE") }

    Text("F10 Visual Memory Vault (${state.document.vaultAssets.size}) & P04 Character Ruler", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = vaultTag, onValueChange = { vaultTag = it }, label = { Text("Tags (CSV)") }, singleLine = true, modifier = Modifier.weight(1f))
        Button(onClick = { onSaveVault("Canvas Ref ${state.document.vaultAssets.size + 1}", vaultTag) }, modifier = Modifier.testTag("btn_save_vault")) { Text("Save to Vault") }
        OutlinedButton(onClick = onToggleRuler, modifier = Modifier.testTag("btn_toggle_ruler")) { Text("8-Head Ruler") }
    }
    state.document.vaultAssets.forEach { asset ->
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF151F28)).padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${asset.title} | Colors: ${asset.dominantColorHexes.joinToString()} | Approved: ${asset.userApproved}", color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { onToggleApproval(asset.id, !asset.userApproved) }) { Text(if (asset.userApproved) "Revoke" else "Approve") }
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("P07 Creative Branches & P08 World Orchard (Active: ${state.document.activeBranchId})", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = branchLabel, onValueChange = { branchLabel = it }, label = { Text("Branch Name") }, singleLine = true, modifier = Modifier.weight(1f))
        Button(onClick = { onForkBranch(branchLabel) }, modifier = Modifier.testTag("btn_fork_branch")) { Text("Fork Branch") }
        OutlinedButton(onClick = { onAddOrchardNode(branchLabel) }, modifier = Modifier.testTag("btn_add_orchard")) { Text("+ Orchard Scene") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
        state.document.branches.forEach { br ->
            OutlinedButton(onClick = { onRollbackBranch(br.branchId) }) { Text("Checkout ${br.label}") }
        }
    }
    val orchard = remember(state.document.unknownFields) { VaultBranchOrchardEngine.readOrchardNodes(state.document) }
    Text("Tap a World Orchard node to jump to its scene & branch:", color = StudioColors.TextSecondary, fontSize = 11.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        orchard.forEach { node ->
            val active = node.branchId == state.document.activeBranchId
            Row(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (active) StudioColors.SkySoft.copy(alpha = 0.16f) else Color(0xFF151F28))
                    .border(1.dp, if (active) StudioColors.SkyAccent else StudioColors.FuturesCardBorder, RoundedCornerShape(10.dp))
                    .clickable { onNavigateOrchardNode(node) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("orchard_node_${node.id}"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${node.title} (@${node.branchId} · ${node.x.toInt()},${node.y.toInt()})",
                    color = if (active) StudioColors.SkySoft else StudioColors.TextPrimary,
                    fontSize = 11.sp
                )
            }
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("P05 Conversational Art Director (Local Deterministic Grammar)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(value = directorCmd, onValueChange = { directorCmd = it }, label = { Text("Command (e.g. 'add text Hi', 'opacity 60', 'fork branch v2')") }, singleLine = true, modifier = Modifier.weight(1f).testTag("input_director_cmd"))
        Button(onClick = { onExecuteDirector(directorCmd) }, modifier = Modifier.testTag("btn_run_director")) { Text("Execute") }
    }
    state.document.artDirectorHistory.takeLast(3).forEach { e ->
        Text("• [${if (e.applied) "APPLIED" else "SKIPPED"}] ${e.instruction} -> ${e.proposedOperation}", color = StudioColors.TextSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun ConstraintsAndRouterTab(
    state: StudioUiState,
    onAddConstraint: (ConstraintKind, String) -> Unit,
    onToggleLock: (String) -> Unit,
    onRunOutpaint: (FuturesAndConstraintsEngine.OutpaintDirection) -> Unit,
    onSetMode: (ProviderMode) -> Unit
) {
    Text("P03 Constraint Constellation (${state.document.constraints.size} locked rules)", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onAddConstraint(ConstraintKind.FORBIDDEN_REGION, "Forbidden Zone") }, modifier = Modifier.testTag("btn_add_forbidden")) { Text("+ Forbidden Zone") }
        OutlinedButton(onClick = { onAddConstraint(ConstraintKind.PROTECTED_SILHOUETTE, "Protected Silhouette") }) { Text("+ Protected Silhouette") }
    }
    state.document.constraints.forEach { c ->
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF151F28)).padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Text("${c.kind.name}: ${c.label} (Locked: ${c.userLocked})", color = Color.White, fontSize = 12.sp)
            OutlinedButton(onClick = { onToggleLock(c.id) }) { Text(if (c.userLocked) "Unlock" else "Lock") }
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("P06 Local Non-Destructive Outpainting", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FuturesAndConstraintsEngine.OutpaintDirection.entries.forEach { dir ->
            OutlinedButton(onClick = { onRunOutpaint(dir) }) { Text(dir.name) }
        }
    }

    HorizontalDivider(color = StudioColors.FuturesDivider)
    Text("P10 Secure Provider Router (Current: ${state.providerMode.name})", style = MaterialTheme.typography.labelLarge.copy(color = StudioColors.SkySoft))
    Text(state.providerHealthSummary, style = MaterialTheme.typography.bodySmall.copy(color = StudioColors.TextSecondary))
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        ProviderMode.entries.forEach { mode ->
            val active = mode == state.providerMode
            OutlinedButton(onClick = { onSetMode(mode) }, modifier = Modifier.testTag("btn_provider_${mode.name.lowercase()}")) {
                Text(mode.name.replace("_", " "), color = if (active) StudioColors.SkyAccent else StudioColors.TextSecondary, fontSize = 10.sp)
            }
        }
    }
}
