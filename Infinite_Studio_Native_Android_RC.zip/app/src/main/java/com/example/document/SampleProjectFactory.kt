package com.example.document

import android.graphics.Color
import com.example.features.FuturesAndConstraintsEngine
import com.example.features.ObjectSurgeryAndMaterialEngine
import com.example.features.TimeAndRecipeEngine
import com.example.features.VaultBranchOrchardEngine
import com.example.features.VectorAndFoundryEngine
import com.example.model.StudioTool
import com.example.model.SymmetryMode
import com.example.render.SparseTileRenderer
import com.example.tools.TileBrushEngine

/**
 * Deterministically synthesizes a repeatable offline sample project exercising:
 * - Multiple raster layers (ink + wash) with preserved original hashes
 * - Active polygon selection & protected silhouette constraint
 * - Futures Table local study acceptance (zero pixels outside mask)
 * - Vector speech balloon with exact lettering + Bezier path
 * - Material intelligence shading region
 * - Creative Branch fork + provenance
 * - Creative Recipe DAG execution
 * - Time Canvas multi-frame keyframes + onion skin
 */
object SampleProjectFactory {

    fun buildSignatureDemo(renderer: SparseTileRenderer): CanonicalDocument {
        val base = CanonicalDocument(
            documentId = "doc_sample_futures",
            title = "One Mark, Three Futures",
            layers = listOf(
                DocumentLayer(id = "layer_ink", name = "Original Ink Mark"),
                DocumentLayer(id = "layer_wash", name = "Sky Underpaint")
            ),
            activeLayerId = "layer_ink"
        )

        var doc = TileBrushEngine.commitStrokeToDocument(
            doc = base,
            renderer = renderer,
            targetLayerId = "layer_ink",
            worldPoints = listOf(
                Vec2(-140f, 60f) to 0.7f,
                Vec2(-40f, -90f) to 0.9f,
                Vec2(80f, -40f) to 0.85f,
                Vec2(140f, 90f) to 0.75f
            ),
            params = TileBrushEngine.StrokeRenderParams(
                tool = StudioTool.INK,
                colorInt = Color.rgb(22, 32, 48),
                preset = TileBrushEngine.defaultPresetForTool(StudioTool.INK, 14f),
                symmetryMode = SymmetryMode.NONE,
                activeMask = null
            )
        )

        doc = TileBrushEngine.commitStrokeToDocument(
            doc = doc,
            renderer = renderer,
            targetLayerId = "layer_wash",
            worldPoints = listOf(
                Vec2(-110f, -20f) to 0.65f,
                Vec2(10f, -30f) to 0.8f,
                Vec2(110f, 20f) to 0.7f
            ),
            params = TileBrushEngine.StrokeRenderParams(
                tool = StudioTool.WATERCOLOR,
                colorInt = Color.rgb(56, 189, 248),
                preset = TileBrushEngine.defaultPresetForTool(StudioTool.WATERCOLOR, 36f, 0.85f),
                symmetryMode = SymmetryMode.NONE,
                activeMask = null
            )
        )

        val mask = SelectionMaskRecord(
            id = "mask_sample_lantern",
            name = "Protected Study Region",
            points = listOf(
                Vec2(-120f, -110f),
                Vec2(120f, -110f),
                Vec2(120f, 110f),
                Vec2(-120f, 110f)
            )
        )
        doc = doc.copy(masks = listOf(mask))
        doc = FuturesAndConstraintsEngine.addConstraint(
            doc = doc,
            kind = ConstraintKind.PROTECTED_SILHOUETTE,
            label = "Lantern Silhouette Lock",
            points = listOf(
                Vec2(-160f, -150f),
                Vec2(-130f, -150f),
                Vec2(-130f, -120f),
                Vec2(-160f, -120f)
            ),
            note = "Preserve outer margin untouched"
        )

        // Explore Futures locally & accept Copper Light (index 2) onto a new layer
        val session = FuturesAndConstraintsEngine.buildFuturesSession(doc, renderer, mask, "warm twilight lantern")
        val (withFuture, _) = FuturesAndConstraintsEngine.acceptBranchToNewLayer(doc, session, 2)
        doc = withFuture
        session.originalBitmap.recycle()
        session.maskBitmap.recycle()
        session.branches.forEach { it.candidateBitmap.recycle(); it.previewBitmap.recycle() }

        // Vector speech balloon + Bezier ribbon
        doc = VectorAndFoundryEngine.addSpeechBalloon(
            doc = doc,
            text = "ONE MARK, THREE FUTURES",
            x = -190f,
            y = -270f
        )
        doc = VectorAndFoundryEngine.addBezierCurve(
            doc = doc,
            points = listOf(Vec2(-160f, 130f), Vec2(0f, 180f), Vec2(160f, 130f))
        )

        // Material region + lighting
        val material = MaterialRegion(
            id = "mat_copper",
            name = "Hammered Copper",
            targetLayerId = "layer_ink",
            baseColorHex = "#D4763E",
            roughness = 0.32f,
            metalness = 0.85f,
            reliefStrength = 0.55f
        )
        doc = ObjectSurgeryAndMaterialEngine.applyMaterialPreviewAsNewLayer(doc, renderer, material)

        // Creative branch fork
        doc = VaultBranchOrchardEngine.forkBranch(doc, "Copper Study Branch", "Sample offline fixture")

        // Recipe DAG execution
        val recipeRun = TimeAndRecipeEngine.executeRecipeGraph(doc)
        doc = doc.copy(recipes = listOf(recipeRun.updatedGraph))

        // Timeline frame capture + second frame
        doc = TimeAndRecipeEngine.captureCurrentLayersToFrame(doc)
        doc = TimeAndRecipeEngine.addTimelineFrame(doc)
        return doc
    }
}
