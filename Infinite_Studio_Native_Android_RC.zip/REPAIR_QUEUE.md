# Repair Queue — Infinite Studio Native Android

Ranked list of remaining environment-blocked hardware/emulator checks, partial UI completeness gaps identified during the independent audit, and P2 performance polish for `HANDOFF_FOR_CHATGPT.md`.

---

## Closed Security Priority (`RQ-SEC-01` — `RESOLVED`)

- **`RQ-SEC-01` Client Credential Boundary Fix (`RESOLVED`):**
  - **Root Cause Fixed:** Root `.env.example` and `secrets-gradle-plugin` caused AI Studio to prompt for `OPENAI_API_KEY` and created a direct `BuildConfig.OPENAI_API_KEY` injection surface plus `ProviderMode.REMOTE_OPT_IN_OPENAI` inside Android.
  - **Verification:** Deleted root `.env.example`, removed `secrets-gradle-plugin` from `libs.versions.toml` / `build.gradle.kts` / `app/build.gradle.kts`, removed direct OpenAI URL/header/mode from `ProviderRouter.kt`, and added `CredentialBoundaryAndBuildArtifactTest` (`3/3 PASSED`) scanning source, Gradle, `BuildConfig`, and `app-debug.apk`.

---

## P0 — Critical Hardware & Emulator Runtime Verification (Environment-Blocked Here)

1. **`RQ-P0-01` Physical Galaxy Tab S9 Ultra S-Pen & Live Emulator `framestats` QA**
   - **Area:** `input/StylusInputRouter.kt`, `ui/canvas/InfiniteCanvasView.kt`, `viewmodel/StudioViewModel.kt`
   - **Cause / Gap:** AI Studio agent sandbox provides no ADB or interactive emulator shell access (`TAB_S9_ULTRA_DEVICE_QA.md`). Synthetic `MotionEvent` tests pass, and `InfiniteCanvasView`/`StudioViewModel` drawing/startup bottlenecks were fixed in code, but live Android runtime UI interaction and `dumpsys gfxinfo framestats` (separating cold-start ART verification from steady-state 120 Hz canvas drawing) remain unmeasured.
   - **Next Action:** Install `app/build/outputs/apk/debug/app-debug.apk` on emulator and physical SM-X910/SM-X916B via USB and run `D01`–`D08` with `adb shell dumpsys gfxinfo com.aistudio.infinitestudio.kqvxzm framestats`.

2. **`RQ-P0-02` Live Loopback Companion USB Tunneling (`adb reverse`)**
   - **Area:** `services/ProviderRouter.kt`, `companion/server.py`
   - **Cause / Gap:** Companion server Python suite passed (`3/3`), and Android OkHttp client passed real localhost socket tests against a JVM test server, while physical USB `adb reverse tcp:8787 tcp:8787` end-to-end execution from an Android device to workstation Python could not run without ADB.
   - **Next Action:** Run `python3 companion/server.py`, execute `adb reverse tcp:8787 tcp:8787`, switch `ProviderRouter` to `LOOPBACK_COMPANION`, confirm dispatch in `FuturesTableDialog`, and record provenance (`D09`).

---

## P1 — Honest UI & Feature Completeness Gaps (`PARTIAL` -> `VERIFIED`)

3. **`RQ-P1-01` Expose Existing Engine Helpers in `StudioWorkspaceSheet` (`F10`, `P04`, `P07`)**
   - **Gap:** `VaultBranchOrchardEngine` already implements and tests `searchVaultAssets` (`F10`), `updateCharacterSheetNotes` / `userApprovedCanon` (`P04`), and `compareBranches` / `cherryPickLayerFromBranch` (`P07`), but Tab 4 of `StudioWorkspaceSheet.kt` does not yet wire UI inputs/buttons for those 4 engine methods.
   - **Next Action:** Add Search Query field + results chip list (`F10`), Canon approval/notes fields (`P04`), and Diff/Cherry-Pick buttons (`P07`) in `VaultBranchDirectorTab`.

4. **`RQ-P1-02` Interactive Direct-Manipulation & Deeper Control Panels (`F01`, `F02`, `F04`, `F05`, `F06`, `F09`)**
   - **Gap:** Features downgraded to `PARTIAL` have real domain math & persistence, but rely on simplified button/slider forms instead of full studio manipulators:
     - `F01` Object Surgery: lacks on-canvas drag-handle bounding box gizmo (currently fixed `+30, -20` nudge button).
     - `F02` Spatial Stage: `pitchDeg` hardcoded to `0f` in Tab 0; lacks canvas camera orbit gesture.
     - `F04` Creative Recipes: executes DAG and tweaks roughness via button, lacks visual node-graph editor.
     - `F05` Time Canvas: exports sprite sheets cleanly, lacks live playback timer & MediaCodec MP4 export.
     - `F06` Material Intelligence: Tab 2 exposes roughness/metalness/relief/azimuth, omits elevation/emissive/per-mask region controls.
     - `F09` Vector & Typography: Tab 1 adds text/balloon/Bezier and exports exact SVG `<text>`, lacks on-canvas node/handle drag editing.

5. **`RQ-P1-03` Legacy Repository File Reconciliation (Git Branch Hygiene)**
   - **Gap:** Original web prototype files (`index.html`, `original_source.html`, `laboratory.*`, `server.py`, `tests/`) were replaced cleanly when initializing the native Android workspace. `original_source.html` (SHA-256 `0e1497037505c011d7837874f5a277c5b65cc030161e36fc33102218f9970b76`) remains intact on upstream `westkitty/Infinite_Studio` `main`.
   - **Next Action:** Merge/push this Android deliverable into a dedicated native branch or `android/` directory without overwriting `main`.

---

## P2 — Performance & Incremental Enhancements

6. **`RQ-P2-01` Replace Small Modal Checkerboard Loops (`ExportDialog`, `FuturesTableDialog`)**
   - **Detail:** `InfiniteCanvasView.kt`'s main 9,672-call per-frame loop was replaced by a cached `BitmapShader`. Infrequent preview boxes inside `ExportDialog.kt` and `FuturesTableDialog.kt` still use ~200-call Compose `Canvas` `drawRect` loops; converting them to a repeated `ImageBitmap` pattern will eliminate allocation noise when opening dialogs.

7. **`RQ-P2-02` Disk Spillover Tier for Large History Stacks**
   - **Area:** `document/TransactionEngine.kt`
   - **Detail:** `TransactionEngine` currently bounds memory to 48 MB / 24 steps in-memory by evicting oldest snapshots; adding temporary PNG swap spillover to `cacheDir/history/` extends deep undo on 16k×16k canvases.

8. **`RQ-P2-03` AndroidX Ink (`androidx.ink`) Low-Latency Front-Buffer Adoption**
   - **Area:** `ui/canvas/InfiniteCanvasView.kt`
   - **Detail:** Integrating Jetpack Ink / `CanvasFrontBufferedRenderer` on One UI 6+/7 after physical S-Pen baseline validation can reduce glass-to-photon latency further.
