# Infinite Studio — Native Android Architecture

Infinite Studio is built as a single-module, single-Activity (`com.example.MainActivity`), landscape-first Jetpack Compose application organized into strict layered packages so domain, document, geometry, rendering, and serialization logic never depend on Composables or `Activity`.

---

## 1. Package Boundaries & Dependency Rule

```
ui/ ──────────────▶ viewmodel/ ──────────▶ features/ & tools/
                                                │
                       input/ ──────────────────┼──▶ render/ ──▶ document/
                       storage/ ────────────────┤
                       services/ ───────────────┘
```

- **`document/`** (`DocumentModels.kt`, `TransactionEngine.kt`, `DocumentArchiveCodec.kt`, `SampleProjectFactory.kt`)
  - Immutable `CanonicalDocument` (`schemaVersion = 3`) with structural tile sharing.
  - `TransactionEngine` maintains undo/redo stacks bounded by `MAX_HISTORY_STEPS = 24` and `48 MB` estimated tile memory.
  - `DocumentArchiveCodec` handles `.iastudio` v3 ZIP containers, lossless `.iastudio` v2 JSON migration, SHA-256 tile verification, zip-slip protection, and PNG header checks.
- **`input/`** (`StylusInputRouter.kt`)
  - Processes raw Android `MotionEvent` streams (`ACTION_DOWN/MOVE/UP/CANCEL`, `ACTION_HOVER_MOVE`, `ACTION_POINTER_DOWN/UP`, Android 13+ `FLAG_CANCELED`).
  - Separates pointer intents (`STYLUS`, `ERASER`, `TOUCH`, `MOUSE`), consumes batched `historySize` samples, extracts pressure/tilt/orientation, implements user-toggleable `sPenGuard`, 2-finger pan/pinch, and 2/3-finger tap undo/redo.
- **`render/`** (`SparseTileRenderer.kt`)
  - Manages sparse `256 × 256` PNG tiles lazily allocated within `DocumentBounds`.
  - Culls tiles outside the viewport (`visibleTileKeysForWorldRect`), caches decoded `Bitmap`s in a `48 MB` `LruCache`, composites provisional strokes separately from committed tiles, and renders `StaticLayout` wrapped vector/balloon text.
- **`tools/`** (`TileBrushEngine.kt`)
  - Tile-native rendering algorithms for `PENCIL`, `INK`, `MARKER`, `WATERCOLOR`, `AIRBRUSH`, `SMUDGE`, `ERASER`, `AI_GUIDANCE`, plus custom brush presets, symmetry transforms, shape guides, scanline flood fill, eyedropper sampling, and tile-multiple `expandBoundsIfNeeded`.
- **`features/`** (All 20 Creative Subsystems)
  - `FuturesAndConstraintsEngine.kt` (`P01`, `P02`, `P03`, `P06`, `F07`)
  - `ObjectSurgeryAndMaterialEngine.kt` (`F01`, `F02`, `F06`)
  - `VectorAndFoundryEngine.kt` (`F08`, `F09`, `P09`)
  - `TimeAndRecipeEngine.kt` (`F03`, `F04`, `F05`)
  - `VaultBranchOrchardEngine.kt` (`F10`, `P04`, `P05`, `P07`, `P08`)
- **`services/`** (`ProviderRouter.kt`)
  - Adapter boundary (`OfflineMockProviderAdapter`, `LoopbackCompanionAdapter`) defaulting strictly to `OFFLINE_LOCAL_ONLY`. Zero third-party AI API keys or direct remote AI URLs exist on the Android client; any optional upstream provider key lives exclusively on the separate host `companion/server.py`.
- **`storage/`** (`ProjectStorageManager.kt`)
  - Atomic draft staging + `recovery_journal.json` in app-private `filesDir/projects/`, Android SAF URI persistence, zero-permission Photo Picker import (`PickVisualMedia`), and `FileProvider` sharing.
- **`viewmodel/`** (`StudioViewModel.kt`)
  - Coordinates input transactions, provisional canvas overlays, `LivingPreviewEngine` debounced jobs, background `Dispatchers.IO` draft inspection / `Dispatchers.Default` bitmap synthesis (`applyBakedTransform`, `mergeDownActiveLayer`, `extractSelectionAsObject`, `saveCurrentCanvasToVault`), debounced autosave, and `StateFlow<StudioUiState>`.
- **`ui/`** (`InfiniteCanvasView.kt`, `TopControlBar.kt`, `LeftBrushDock.kt`, `LayersDrawer.kt`, `BottomToolDock.kt`, `FuturesTableDialog.kt`, `BrushStudioDialog.kt`, `StudioWorkspaceSheet.kt`, `DiagnosticsDialog.kt`, `ProjectVaultDialog.kt`, `ExportDialog.kt`, `ColorStudioPopover.kt`)
  - Tablet-optimized glassmorphic floating workspace over a central full-bleed native `Canvas` view (`InfiniteCanvasView`).

---

## 2. Lifecycle & Threading Model

- **Input, Checkerboard & Selection Marquee:** Handled in `InfiniteCanvasView` (`StudioNativeCanvasView`) with zero per-frame allocations (`BitmapShader` 48×48 tile pattern in 1 draw call, preallocated `Paint`/`DashPathEffect`/`Path`), lightweight provisional `Bitmap` stroke overlay, and View-local 30 Hz selection marquee invalidation (zero Compose recomposition churn).
- **Startup & Bitmap Operations:** `StudioViewModel.init` checks `hasRecoverableDraft()` on `Dispatchers.IO`, and heavy document/bitmap operations (`applyBakedTransform`, `mergeDownActiveLayer`, `extractSelectionAsObject`, `saveCurrentCanvasToVault`) run on `Dispatchers.Default`.
- **Process Death / Recovery:** `StudioViewModel` debounces `saveLocalDraftAtomic()` on document changes (`2.5s`), writing `.tmp` archives and updating `recovery_journal.json` only after complete flush.
- **Living Preview Backpressure:** `LivingPreviewEngine` uses debounced `Job` cancellation (`MutableStateFlow` revision guard + battery/low-power pause switch) so rapid S-Pen strokes cancel stale thumbnail renders cleanly.
