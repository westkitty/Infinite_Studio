# Requirement Traceability Matrix — Infinite Studio

Maps every architectural invariant, end-to-end journey (`J01`–`J08`), and creative system (`F01`–`F10`, `P01`–`P10`) to concrete source symbols, test evidence, and remaining verification boundaries.

---

## 1. End-to-End Test Journeys (`J01`–`J08`)

| Journey | Requirement | Implementation Path | Automated Test Proof | Result |
|---|---|---|---|---|
| **J01** | Create -> S-Pen brush/color -> layers -> viewport transform -> undo/redo -> atomic save -> reopen -> export PNG | `TileBrushEngine.commitStrokeToDocument` -> `TransactionEngine` -> `ProjectStorageManager.saveLocalDraftAtomic` / `loadLocalDraft` -> `renderExportPreview` | `EndToEndJourneysTest.J01 paint save reopen and deterministic flattened export` | `PASS` (Robolectric SDK 35 RNG) |
| **J02** | Object Surgery: flattened selection -> extract transparent object -> transform -> speculative BG repair label -> revert -> original unchanged | `ObjectSurgeryAndMaterialEngine.extractObjectFromSelection`, `moveSemanticObject`, `revertObjectExtraction` | `EndToEndJourneysTest.J02 object surgery extracts semantic object repairs hole speculatively and reverts cleanly` | `PASS` (Robolectric SDK 35 RNG) |
| **J03** | Protected mask -> 3 honest local Futures (`LOCAL_STUDY`) -> accept onto new layer -> original hashes invariant -> **0 pixels outside mask** -> Forensics heatmap | `FuturesAndConstraintsEngine.buildFuturesSession`, `acceptBranchToNewLayer`, `countNonTransparentPixelsOutsideMask`, `computeForensicsReport` | `EndToEndJourneysTest.J03 futures produces 3 honest local studies and zero pixels mutate outside mask` | `PASS` (Robolectric SDK 35 RNG) |
| **J04** | Exact vector text + speech balloon + Bezier + Material lighting + Time frames sprite sheet + Production Foundry ZIP roundtrip | `VectorAndFoundryEngine`, `ObjectSurgeryAndMaterialEngine`, `TimeAndRecipeEngine` | `EndToEndJourneysTest.J04 vector exact SVG material preview time frames and foundry bundle roundtrip` | `PASS` (Robolectric SDK 35 RNG) |
| **J05** | 3+ stage Creative Recipe DAG -> downstream param edit -> only dependent nodes recompute (upstream reused via content hash) | `TimeAndRecipeEngine.executeRecipeGraph`, `updateRecipeNodeParameter` | `EndToEndJourneysTest.J05 creative recipe DAG selective descendant recompute skips unchanged upstream nodes` | `PASS` (Robolectric SDK 35 RNG) |
| **J06** | Vault tag & RGB Euclidean color similarity search + explicit `userApproved` flag + local Art Director command grammar | `VaultBranchOrchardEngine.addVaultAsset`, `searchVaultAssets`, `executeArtDirectorCommand` | `EndToEndJourneysTest.J06 vault tag and RGB color similarity search plus explicit approval and local Art Director` | `PASS` (Robolectric SDK 35 RNG) |
| **J07** | Strict offline egress rejection + explicit companion consent gating + mock provider idempotency, cancellation, and stale revision rejection | `ProviderRouter`, `OfflineMockProviderAdapter`, `LoopbackCompanionAdapter`, `companion/server.py` | `ProviderAndBranchesTest.J07...` & `companion/test_companion.py` | `PASS` (Android JVM + Python unittest) |
| **J08** | Corrupt archive / zip-slip / future schema / canceled stroke / process-death draft recovery + SampleProjectFactory roundtrip | `DocumentArchiveCodec.readDocument`, `StylusInputRouter`, `ProjectStorageManager`, `SampleProjectFactory` | `DocumentAndArchiveTests`, `StylusAndTileRendererTests`, `EndToEndJourneysTest.J08...` | `PASS` (Robolectric SDK 35 RNG) |

---

## 2. Core Non-Negotiable Machine Checks

| Machine Check | Enforcing Function / Class | Verified By |
|---|---|---|
| Pre-existing layer pixel hash equality after Futures accept | `DocumentLayer.pixelContentHash()` + `FuturesAndConstraintsEngine.acceptBranchToNewLayer` | `EndToEndJourneysTest.J03` (`origSketchHash == acceptedDoc.layers.first().pixelContentHash()`) |
| Zero committed pixels outside allowed mask | `FuturesAndConstraintsEngine.countNonTransparentPixelsOutsideMask` | `EndToEndJourneysTest.J03` (`assertEquals(0, outsidePixels)`) |
| Undo/redo & branch isolation (zero mutable aliasing) | `TransactionEngine` + immutable `tiles: Map<String, ByteArray>` + `VaultBranchOrchardEngine.forkBranch` snapshot | `DocumentAndArchiveTests`, `ProviderAndBranchesTest` |
| Lossless `.iastudio` v2 migration (no silent flattening) | `DocumentArchiveCodec.readLegacyOrJsonDocument` | `DocumentAndArchiveTests.legacy v2 json project...` |
| Exact SVG `<text>` lettering & sprite sheet dimensions | `VectorAndFoundryEngine.exportDocumentToSvg`, `TimeAndRecipeEngine.exportSpriteSheet` | `EndToEndJourneysTest.J04` |
| Zip-slip, corrupt PNG, future-version & payload bounds guards | `DocumentArchiveCodec.validateSafeEntryPath`, `validatePngHeader`; `companion/server.py` | `DocumentAndArchiveTests`, `companion/test_companion.py` |
| Zero client secrets / zero OpenAI endpoints in APK + default offline gating | `ProviderRouter` (3 modes), removed `.env.example` & `secrets-gradle-plugin` | `CredentialBoundaryAndBuildArtifactTest` (3/3) & `ProviderAndBranchesTest.J07` |

---

## 3. Feature System Source & Audit Scope (`F01`–`F10`, `P01`–`P10`)

- **F01 Object Surgery (`PARTIAL`):** `ObjectSurgeryAndMaterialEngine.extractObjectFromSelection`, `moveSemanticObject`, `revertObjectExtraction` -> `StudioWorkspaceSheet` Tab 0 (`EndToEndJourneysTest.J02`). Canvas drag-handle transform gizmo omitted.
- **F02 Spatial Stage (`PARTIAL`):** `SpatialStageState`, `ObjectSurgeryAndMaterialEngine.renderSpatialStageComposite` -> `StudioWorkspaceSheet` Tab 0 (`WorkspaceAdvancedSystemsTest`). `pitchDeg` hardcoded to `0f` in UI; no direct canvas camera orbit.
- **F03 Living Preview (`VERIFIED`):** `LivingPreviewEngine` (`TimeAndRecipeEngine.kt`) -> `StudioViewModel` -> `StudioWorkspaceSheet` Tab 3 (`WorkspaceAdvancedSystemsTest`).
- **F04 Creative Recipes (`PARTIAL`):** `RecipeGraph`, `TimeAndRecipeEngine.executeRecipeGraph`, `updateRecipeNodeParameter` -> `StudioWorkspaceSheet` Tab 3 (`EndToEndJourneysTest.J05`). Visual node-graph canvas editor omitted.
- **F05 Time Canvas (`PARTIAL`):** `TimelineState`, `TimeAndRecipeEngine.addTimelineFrame`, `captureCurrentLayersToFrame`, `exportSpriteSheet` -> `StudioWorkspaceSheet` Tab 2 (`EndToEndJourneysTest.J04`). Live looping playback & MP4 encoder omitted.
- **F06 Material Intelligence (`PARTIAL`):** `MaterialRegion`, `ObjectSurgeryAndMaterialEngine.applyMaterialPreviewAsNewLayer` -> `StudioWorkspaceSheet` Tab 2 (`EndToEndJourneysTest.J04`). Elevation, emissive & per-mask region painter UI omitted.
- **F07 Visual Forensics (`VERIFIED`):** `ForensicsReport`, `FuturesAndConstraintsEngine.computeForensicsReport` -> `StudioWorkspaceSheet` Tab 3 (`EndToEndJourneysTest.J03`).
- **F08 Production Foundry (`VERIFIED`):** `FoundryManifest`, `VectorAndFoundryEngine.exportFoundryBundleZip`, `verifyFoundryBundleZip` -> `StudioWorkspaceSheet` Tab 1 (`EndToEndJourneysTest.J04`, `WorkspaceAdvancedSystemsTest`).
- **F09 Vector & Typography (`PARTIAL`):** `VectorObject`, `VectorAndFoundryEngine.addTextBox`, `addSpeechBalloon`, `addBezierCurve`, `exportDocumentToSvg` -> `StudioWorkspaceSheet` Tab 1 (`EndToEndJourneysTest.J04`). On-canvas vector/Bezier handle manipulation UI omitted.
- **F10 Visual Memory Vault (`PARTIAL`):** `VaultAssetRecord`, `VaultBranchOrchardEngine.addVaultAsset`, `searchVaultAssets` -> `StudioWorkspaceSheet` Tab 4 (`EndToEndJourneysTest.J06`). Similarity/tag query box omitted from Tab 4 UI.
- **P01 Futures Table (`VERIFIED` Local Studies + Masked Accept):** `FuturesTableSessionV3`, `FuturesAndConstraintsEngine` -> `FuturesTableDialog.kt` (`EndToEndJourneysTest.J03`, `UiFlowsRobolectricTest`).
- **P02 AI Brush (`VERIFIED` Local Guidance):** `AiGuidanceMark`, `StudioTool.AI_GUIDANCE`, `FuturesAndConstraintsEngine.addGuidanceMark` -> `BottomToolDock.kt` & `InfiniteCanvasView.kt` (`WorkspaceAdvancedSystemsTest`).
- **P03 Constraint Constellation (`VERIFIED`):** `ConstraintRecord`, `ConstraintKind`, `FuturesAndConstraintsEngine.evaluateConstraintConflicts` -> `StudioWorkspaceSheet` Tab 5 (`EndToEndJourneysTest.J03`).
- **P04 Character Studio (`PARTIAL`):** `CharacterSheet`, `InfiniteCanvasView` ruler overlay -> `StudioWorkspaceSheet` Tab 4 (`WorkspaceAdvancedSystemsTest`, `UiFlowsRobolectricTest`). Proportion notes & canon approval UI editors omitted from Tab 4.
- **P05 Art Director (`VERIFIED` Local Grammar):** `ArtDirectorEntry`, `VaultBranchOrchardEngine.executeArtDirectorCommand` -> `StudioWorkspaceSheet` Tab 4 (`EndToEndJourneysTest.J06`).
- **P06 Outpainting (`PARTIAL`):** `FuturesAndConstraintsEngine.generateLocalOutpaintCandidate` -> `StudioWorkspaceSheet` Tab 5 (`ProviderAndBranchesTest`). Local edge-bleed only (generative seam fill behind P10).
- **P07 Creative Branches (`PARTIAL`):** `BranchNode`, `VaultBranchOrchardEngine.forkBranch`, `rollbackToBranch` -> `StudioWorkspaceSheet` Tab 4 (`ProviderAndBranchesTest`). `compareBranches` & `cherryPickLayerFromBranch` lack Tab 4 UI controls.
- **P08 World Orchard (`VERIFIED`):** `VaultBranchOrchardEngine.addOrchardNode` -> `StudioViewModel.navigateToOrchardNode` -> `StudioWorkspaceSheet` Tab 4 (`WorkspaceAdvancedSystemsTest`, `UiFlowsRobolectricTest`).
- **P09 Asset Workshop (`VERIFIED`):** `WorkshopTemplate`, `VectorAndFoundryEngine.WORKSHOP_TEMPLATES`, `applyWorkshopTemplate` -> `StudioWorkspaceSheet` Tab 1 (`WorkspaceAdvancedSystemsTest`).
- **P10 Secure Provider Router (`PARTIAL`):** `ProviderRouter`, `OfflineMockProviderAdapter`, `LoopbackCompanionAdapter`, `companion/server.py` -> `StudioWorkspaceSheet` Tab 5 & `FuturesTableDialog.kt` (`ProviderAndBranchesTest.J07`, `WorkspaceAdvancedSystemsTest`, `CredentialBoundaryAndBuildArtifactTest`, `companion/test_companion.py`). USB `adb reverse` (`D09`) & live host remote inference unrun.
