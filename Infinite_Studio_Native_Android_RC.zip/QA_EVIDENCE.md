# QA Evidence — Infinite Studio Native Android

**Date:** 2026-11-15  
**Environment:** Cloud Linux Android Build Sandbox (JDK 21, AGP 9.1.1, Kotlin 2.2.21, `compileSdk = 36`, `minSdk = 26`, `targetSdk = 36`)  
**No-Spend / No-Deploy / Zero-Client-Secret Scope:** Zero API keys or `.env` files in the Android client/APK; zero live paid OpenAI calls; zero server deployments; zero upstream `main` branch modifications.

---

## 1. Executed Build, Artifact & Test Checks

- **Android Compilation (`compile_applet` & `gradle assembleDebug`):** `PASSED`
  - Produced APK: `app/build/outputs/apk/debug/app-debug.apk`
  - Measured Size: `19,133,151` bytes (`18.25 MiB`)
  - Measured SHA-256: `fbdf44242128a9aec58cc60a56058da363a42c6266feab146635944b5c01d613`
  - APK Credential Audit (`zipfile` & `CredentialBoundaryAndBuildArtifactTest`): `0` `.env` entries, `0` `OPENAI_API_KEY` occurrences, `0` `api.openai.com` occurrences across DEX/assets/resources.
- **Robolectric + Compose UI + Security Test Execution:** `gradle :app:testDebugUnitTest` -> `BUILD SUCCESSFUL` (**26 tests completed, 0 failed, 0 skipped**)
- **Python Companion Test Suite:** `python3 -m unittest discover -s companion -p "test_*.py" -v` -> **`Ran 3 tests in 1.527s — OK`**

> **Runtime Note:** Android JVM tests run under **Robolectric 4.14.1** at `@Config(sdk = [35])` with `@GraphicsMode(GraphicsMode.Mode.NATIVE)` (real Skia/libhwui pixel rasterization, `Bitmap.compress`, `BitmapFactory`, `Canvas.clipPath`, Jetpack Compose `createAndroidComposeRule<ComponentActivity>()`, and synthetic `MotionEvent` sequences). `UiFlowsRobolectricTest` uses `qualifiers = "w1280dp-h800dp-land"` to validate tablet landscape Compose layout sizing and interactions.

---

## 2. Exact Executed Android Tests (`gradle :app:testDebugUnitTest`, 26/26 Passed)

### `com.example.DocumentAndArchiveTests` (4/4 Passed)
1. `transaction engine supports undo redo redo-clearing and structural tile sharing`
2. `zip-slip traversal truncated archive and unsupported future version fail safely`
3. `v3 archive write and read roundtrip preserves multi-layer tiles checksums and unknown fields`
4. `legacy v2 json project migrates losslessly without flattening layers`

### `com.example.StylusAndTileRendererTests` (3/3 Passed)
5. `stylus input router distinguishes stylus touch eraser and consumes historical batched samples` (also verifies `ACTION_CANCEL` rollback)
6. `sPenGuard routes single touch to pan instead of stroke`
7. `sparse tile renderer lazily allocates only touched tiles and culls viewport cleanly` (verifies `1..4` tiles allocated in `2048×2048` canvas)

### `com.example.EndToEndJourneysTest` (7/7 Passed)
8. `J01 paint save reopen and deterministic flattened export`
9. `J02 object surgery extracts semantic object repairs hole speculatively and reverts cleanly`
10. `J03 futures produces 3 honest local studies and zero pixels mutate outside mask` (`changedPixelsOutsideMask == 0`, `changedPixelsInsideMask > 0`, original layer SHA-256 unchanged)
11. `J04 vector exact SVG material preview time frames and foundry bundle roundtrip` (exact `<text>` SVG preservation, `384px` sprite sheet, Foundry ZIP reimport verification)
12. `J05 creative recipe DAG selective descendant recompute skips unchanged upstream nodes`
13. `J06 vault tag and RGB color similarity search plus explicit approval and local Art Director`
14. `J08 corrupt input bad checksum and process death recovery preserve last good project and sample project roundtrips`

### `com.example.ProviderAndBranchesTest` (2/2 Passed)
15. `J07 offline mode blocks external egress and mock provider honors idempotency cancellation and stale revision` (also enforces `LOOPBACK_COMPANION` `CONSENT_REQUIRED` gate)
16. `creative branches fork diff rollback and cherry pick have zero mutable aliasing`

### `com.example.WorkspaceAdvancedSystemsTest` (6/6 Passed)
17. `F02 spatial stage assigns depth planes renders distinct parallax composites and roundtrips v3`
18. `F03 living preview coalesces rapid revisions and honors low power battery pause`
19. `P04 character studio ruler toggle and notes persist cleanly across v3 archive`
20. `P08 world orchard and P09 asset workshop integrate with StudioViewModel and Foundry`
21. `P10 loopback companion adapter executes real OkHttp HTTP calls against loopback server` (`127.0.0.1:0` real socket roundtrip)
22. `StudioViewModel core CUJ paint undo redo layers AI guidance preset and redacted diagnostics`

### `com.example.UiFlowsRobolectricTest` (1/1 Passed)
23. `UI CUJ opens Workspace Hub tabs toggles ruler jumps Orchard node loads Sample and accepts Futures study`

### `com.example.CredentialBoundaryAndBuildArtifactTest` (3/3 Passed)
24. `BuildConfig and ProviderMode contain zero OpenAI credentials or client remote endpoints`
25. `Android source resources Gradle config and generated BuildConfig exclude OpenAI keys and secrets plugin` (also scans `app/build/outputs/apk/debug/app-debug.apk` DEX/assets/resources)
26. `Offline startup painting undo and redacted diagnostics operate with zero network or API keys`

---

## 3. Executed Companion Python Tests (`companion/test_companion.py`, 3/3 Passed)

1. `test_auth_required_and_health_capabilities` (401 without bearer token, 200 `/health` & `/capabilities`)
2. `test_submit_idempotency_status_cancel_delete` (PNG transform produces distinct PNG output, idempotency replay returns identical `jobId`, `GET`, `POST /cancel`, `DELETE`)
3. `test_validation_stale_revision_bad_mime_and_consent_gate` (415 non-PNG rejected, 409 stale revision rejected, 403 `CONSENT_REQUIRED` enforced)

---

## 4. Rendering & UI-Thread Performance Audit (Code Fixes + Honest Sandbox Disclosure)

During performance audit of reported emulator skipped frames / startup hitch, two real bottlenecks were found in code and fixed:
1. **`InfiniteCanvasView.kt` (`StudioNativeCanvasView`):**
   - *Before:* Allocated fresh `Paint`/`DashPathEffect`/`Path` objects every `onDraw()` and drew the canvas checkerboard inside a nested cell loop (~9,672 `canvas.drawRect()` calls per frame on a 2960×1848 screen), while Compose drove a 30 Hz `LaunchedEffect` recomposing the root layout during selection marquee animation.
   - *Fix Applied:* Cached a `48×48` two-tone `BitmapShader` `Paint` (drawn in **1** `drawRect` call), hoisted all `Paint`/`Path`/`DashPathEffect` instances to class fields, and moved selection marquee stepping into a lightweight View-local `Runnable` calling `postInvalidateOnAnimation()`.
2. **`StudioViewModel.kt`:**
   - *Before:* `init` executed synchronous disk draft lookup (`hasRecoverableDraft()`) on startup, and bitmap-heavy transforms (`applyBakedTransform`, `mergeDownActiveLayer`, `extractSelectionAsObject`, `saveCurrentCanvasToVault`) ran synchronously on main caller context.
   - *Fix Applied:* Moved `hasRecoverableDraft()` to `Dispatchers.IO` and heavy bitmap transforms onto `Dispatchers.Default` via `withContext`.
3. **Remaining Low-Frequency Modal Canvas Loops (Documented):**
   - `ExportDialog.kt` and `FuturesTableDialog.kt` still render small Compose `Canvas` checkerboards (~200 rects inside static thumbnail preview boxes when those dialogs are open); these are non-continuous modals and did not cause continuous 60/120 Hz scroll/draw jank, though they are logged as P2 cleanup in `REPAIR_QUEUE.md`.

---

## 5. Explicitly NOT EXECUTED / Environment-Blocked

| Item | Reason | Reference |
|---|---|---|
| Live emulator launch, UI click-through on streaming emulator, & `adb shell dumpsys gfxinfo framestats` | AI Studio agent execution sandbox provides **no ADB bridge and no interactive emulator access**; startup vs sustained frame metrics cannot be captured here. | `TAB_S9_ULTRA_DEVICE_QA.md` (`D01`–`D08`) |
| Physical Galaxy Tab S9 Ultra S-Pen latency, hover height, palm ergonomics, 120 Hz `framestats` | No physical device / ADB in sandbox | `TAB_S9_ULTRA_DEVICE_QA.md` (`D01`–`D08`) |
| Android ↔ Python Companion live loopback over USB `adb reverse tcp:8787 tcp:8787` | No physical device / ADB available here (Android OkHttp client verified separately against JVM loopback server) | `TAB_S9_ULTRA_DEVICE_QA.md` (`D09`) |
| Live remote host upstream OpenAI image-edit execution | Forbidden by no-paid-API rule & zero client credential policy | `BACKEND_CONTRACT.md` |
