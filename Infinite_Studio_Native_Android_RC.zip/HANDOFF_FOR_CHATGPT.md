# Handoff for Independent Audit & Repair (`HANDOFF_FOR_CHATGPT.md`)

## 1. Project Identity & Baseline Context
- **Product:** Infinite Studio — The Futures Table (Native Android)
- **Package / App ID:** `namespace = "com.example"`, `applicationId = "com.aistudio.infinitestudio.kqvxzm"`
- **Target Device:** Samsung Galaxy Tab S9 Ultra (landscape-first, S-Pen-first)
- **Upstream Repository Baseline:** `https://github.com/westkitty/Infinite_Studio` (Contract reference commit `242534065f7035f57a44bb400cb30bc2cd74387d`)
- **Portable Delivery Artifacts:**
  - Debug APK: `app/build/outputs/apk/debug/app-debug.apk` (`19,133,151` bytes, SHA-256 `fbdf44242128a9aec58cc60a56058da363a42c6266feab146635944b5c01d613`)
  - Clean Portable Source Archive: `Infinite_Studio_Native_Android_RC.zip` (verified against `SOURCE_MANIFEST.json` and clean extraction test build)

---

## 2. Six-Point Independent Audit & Repair Summary

### 1) Credential Boundary & Remaining Security Posture (`FIXED & VERIFIED`)
- **Issue Resolved:** Prior build included root `.env.example`, `secrets-gradle-plugin`, `BuildConfig.OPENAI_API_KEY`, and `ProviderMode.REMOTE_OPT_IN_OPENAI`, prompting AI Studio for `OPENAI_API_KEY`.
- **Closure:** Deleted root `.env.example`, removed `secrets-gradle-plugin` from `gradle/libs.versions.toml`, `build.gradle.kts`, and `app/build.gradle.kts`, removed `REMOTE_OPT_IN_OPENAI` and `api.openai.com` from `ProviderRouter.kt`, updated `StudioModels.kt`/`FuturesTableDialog.kt`/`MainActivity.kt`, and added `CredentialBoundaryAndBuildArtifactTest` (`3/3 PASSED`) verifying `BuildConfig`, Gradle configs, source files, and built APK DEX/assets/resources contain **zero** API keys or OpenAI endpoints.
- **Remaining Boundary Risk:** `android.permission.INTERNET` remains declared solely for opt-in `LOOPBACK_COMPANION` (`127.0.0.1:8787`). Optional host upstream credentials live **exclusively** inside the separately hosted Python environment (`companion/.env.example`) on the user's workstation, never inside the APK.

### 2) Clean-Build Reproducibility
- Always invoke system **`gradle`** (do **not** use `./gradlew`; the container uses system Gradle `9.3.1` with JDK `21`, AGP `9.1.1`, Kotlin `2.2.21`).
- Ensure `ANDROID_SDK_ROOT` is set in your environment; do **not** create or commit `local.properties` or `.env`.
- Because `debug.keystore*` is intentionally excluded from `Infinite_Studio_Native_Android_RC.zip`, run `gradle :app:testDebugUnitTest` directly, or generate a local throwaway debug keystore before running `gradle assembleDebug` on a fresh machine:
  ```bash
  keytool -genkey -v -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
  gradle assembleDebug
  gradle :app:testDebugUnitTest
  python3 -m unittest discover -s companion -p "test_*.py" -v
  ```
- Clean-extraction reproducibility (`gradle :app:testDebugUnitTest` & `python3 -m unittest`) from `Infinite_Studio_Native_Android_RC.zip` was verified in `/tmp/rc_verify`.

### 3) Unverified Real-Device & Live-Emulator Interactions (Honest Disclosure)
The AI Studio cloud build sandbox has **no ADB bridge and no interactive emulator control**, so the following remain **UNVERIFIED on live Android Runtime / Hardware**:
1. Launching and manually interacting with the live Compose/View hierarchy in a streaming or physical emulator (`dumpsys gfxinfo framestats`, startup cold/warm timing).
2. Physical Samsung Galaxy Tab S9 Ultra Wacom EMR S-Pen latency, tilt/pressure curves, hover cursor, resting palm ergonomics, and 120 Hz frame pacing (`TAB_S9_ULTRA_DEVICE_QA.md` `D01`–`D08`).
3. Android SAF (`CreateDocument`/`OpenDocument`), Zero-Permission Photo Picker (`PickVisualMedia`), and physical USB `adb reverse tcp:8787 tcp:8787` loopback pairing with `companion/server.py` (`D09`).

### 4) Performance Defects Found & Fixes Applied
- **Fixed in `InfiniteCanvasView.kt` (`StudioNativeCanvasView`):**
  - Replaced ~9,672 per-frame nested `canvas.drawRect()` checkerboard calls with a cached `48×48` two-tone `BitmapShader` `Paint` (**1** draw call per frame).
  - Preallocated all `Paint`, `DashPathEffect`, and scratch `Path` objects outside `onDraw()`.
  - Replaced Compose's 30 Hz `LaunchedEffect` marquee timer loop (which forced root Compose recomposition 30x/sec whenever a selection existed) with a self-contained View-local `Runnable` (`postInvalidateOnAnimation()`).
- **Fixed in `StudioViewModel.kt`:**
  - Moved startup `storageManager.hasRecoverableDraft()` off the caller/main thread onto `Dispatchers.IO`.
  - Moved heavy bitmap processing (`applyBakedTransform`, `mergeDownActiveLayer`, `extractSelectionAsObject`, `saveCurrentCanvasToVault`) onto `Dispatchers.Default`.
- **Remaining Minor Defect (Non-Critical):** `ExportDialog.kt` and `FuturesTableDialog.kt` contain small ~200-rect Compose `Canvas` checkerboards inside static modal preview boxes when those dialogs are open (`RQ-P2-01`).

### 5) Companion-Service Integration (`companion/server.py`)
- Pure Python 3 stdlib HTTP server binding strictly to `127.0.0.1:8787`, enforcing bearer token auth (`401`), PNG header validation (`415`), stale revision conflict (`409`), idempotency keys, explicit consent gate (`403 CONSENT_REQUIRED`), `POST /cancel`, and `DELETE` + TTL cleanup.
- **Verified:** All 3 tests in `companion/test_companion.py` pass, and Android `LoopbackCompanionAdapter` (`WorkspaceAdvancedSystemsTest`) executes real OkHttp socket calls over localhost.
- **Unrun:** USB `adb reverse tcp:8787 tcp:8787` from physical tablet + optional host-side remote upstream image edit call.

### 6) Remaining Incomplete Features (`PARTIAL` Audit) & Git Branch Hygiene
- After strict code-level auditing (`BUILD_STATUS.md`), **9 systems are `VERIFIED`** (`F03`, `F07`, `F08`, `P01`, `P02`, `P03`, `P05`, `P08`, `P09`) and **11 systems are honestly classified `PARTIAL`**:
  - Engine complete / partial UI exposure: `F10` (missing search bar in Tab 4), `P04` (missing notes/canon toggle UI in Tab 4), `P07` (missing Diff & Cherry-Pick UI buttons in Tab 4).
  - Simplified Tab controls vs full studio direct manipulation: `F01` (nudge button vs canvas handle gizmo), `F02` (hardcoded `pitch=0f` & no canvas orbit), `F04` (run/tweak buttons vs visual node graph), `F05` (sprite sheet export vs live playback timer & MP4), `F06` (subset of material sliders exposed), `F09` (add/export buttons vs on-canvas vector node dragging), `P06` (local edge-bleed outpaint only), `P10` (USB `adb reverse` unrun).
- **Git Branch Preservation Rule:** During the initial import-rewrite, legacy web files (`index.html`, `original_source.html`, `laboratory.*`, `server.py`, `tests/`) were replaced cleanly inside the Android build workspace. Never push this directory over upstream `main` directly; merge onto a dedicated native branch or under `android/` so `original_source.html` (`0e1497037505c011d7837874f5a277c5b65cc030161e36fc33102218f9970b76`) remains intact on `main`.

---

## 3. Recommended Independent Verification Order (`QQQ`)
1. Extract `Infinite_Studio_Native_Android_RC.zip` into a clean directory, verify files against `SOURCE_MANIFEST.json`, and run `gradle assembleDebug && gradle :app:testDebugUnitTest` (`26/26`) plus `python3 -m unittest discover -s companion -p "test_*.py" -v` (`3/3`).
2. Inspect `CredentialBoundaryAndBuildArtifactTest.kt` and `ProviderRouter.kt` to confirm zero APK credentials or OpenAI endpoints.
3. Inspect `EndToEndJourneysTest.kt` (`J01`–`J08`) and `UiFlowsRobolectricTest.kt` (`w1280dp-h800dp-land`).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on a physical Samsung Galaxy Tab S9 Ultra and execute `TAB_S9_ULTRA_DEVICE_QA.md` (`D01`–`D09`) with `dumpsys gfxinfo framestats`.
5. Complete P1 Tab 4 UI bindings (`RQ-P1-01` in `REPAIR_QUEUE.md`) and direct-manipulation enhancements (`RQ-P1-02`).
